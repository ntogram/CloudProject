#!/bin/bash

#Check for additional libraries netstat and jq
mode=$1
#echo "Check Port Availability"
echo "Check if necessary package net-tool for this process is installed"


#check if netool is installed

dpkg -s net-tools &> /dev/null

if [ $? -eq 1 ]; then
   echo Package net-tool is not installed
  echo Package is installing now. Please wait
  sudo apt install net-tools
else
    echo Package is already installed
fi

echo "Check if necessary package jq for this process is installed"


#check if jq is installed

dpkg -s jq &> /dev/null

if [ $? -eq 1 ]; then
   echo Package net-tool is not installed
  echo Package is installing now. Please wait
  sudo apt install jq
else
    echo Package is already installed
fi

#initialize ports
kubeapi_port=null
kubelet_port=null
kube_scheduler=null
kube_controller=null
kube_proxy_metrics=null
kube_proxy_healthz=null



#mode='auto'

if [[ $mode == "auto" ]]; then
	echo "default ports"
	kubeapi_port=8080
	kubelet_port=10248
	kube_scheduler=10251
	kube_controller=10252
	kube_proxy_metrics=10249
	kube_proxy_healthz=10256
else
	if [[ $mode == "json" ]]; then
		echo "json file"
		filename=$2
#check if filename is json
		if [ ${filename: -5} == ".json" ]; then
#check if exists file with this filename
	exist="$(find . -name $filename)"
			if [ -z  "$exist" ]; then
				echo "File "$filename" not found" 
				exit
			fi
	
        
	
		else
			echo "Not Valid file"
			exit
		fi

		echo "filename is "$filename
		kubeapi_port="$(jq .kube_apiserver $filename)"
		kubelet_port="$(jq .kubelet $filename)"
		kube_scheduler="$(jq .kube_scheduler $filename)"
		kube_controller="$(jq .kube_controller_manager $filename)"
		kube_proxy_metrics="$(jq .kube_proxy_metrics $filename)"
		kube_proxy_healthz="$(jq .kube_proxy_healthz $filename)"
	else
		if [[ $mode == "parameters" ]]; then
			echo "some parameters"
			kubeapi_port=$2
			kubelet_port=$3
			kube_scheduler=$4
			kube_controller=$5
			kube_proxy_metrics=$6
			kube_proxy_healthz=$7
		else
			if [[ $mode == "help" ]]; then
				echo "Help mode"
				echo "There are 3 types of modes(auto,json,parameters) given as first argument"
				echo "1)Auto Mode"
				echo "Change services to default"
                                echo "kube-api server 8080"
                                echo "kubelet 10248"
                                echo "kube-scheduler 10251"
                                echo "kube-controller-manager 10252"
                                echo "proxy:port for metrics 10249"
                                echo "proxy:port for checking health:10256"
				echo "2)Json Mode"
                                echo " EXcept for json as first argument, a second argument must be given"
                                echo " It is a json file as configuration file for ports service"
				echo "each element of given json has  the following format \"service_name\":port_number"
                                echo "Services names can  be given in any order and some service can be omitted- this is for services that should not  change port but services must be  written  in a specific way:"
				echo "kube_apiserver"
				echo "kubelet"
                                echo "kube_scheduler"
				echo "kube_controller_manager"
				echo "kube_proxy_metrics"
				echo "kube_proxy_healthz"
				echo "there is an example json file in blog documentation site"
				echo "3)Parameters Mode"
				echo "First given argument-> parameters. The following arguments must be port numbers. Argument 2 for kube_apiserver,	Argument 3 for kubelet,Argument 4 for kube_scheduler,Argument 5 for kube_controller_manager,Argument 6 for kube_proxy_metrics,Argument 7 for kube_proxy_healthz"
				echo "Ports for services must be given in this order and only the last elements for ports can be omitted. For omitting	some intermediate  port  argument use none- this  means that port for this service does not change."
				echo "Some examples exists in blog site documentation"	
				exit
			else
				mode="unknown"
				echo 'Mode is '$mode
				exit
                                				
			fi
		fi
	fi
fi

re='^[0-9]+$'
#check if user does not want to change this port 
if [ "$kubeapi_port" = "null" ] || [ "$kubeapi_port" = "none" ] || [ -z  "$kubeapi_port" ] ; then
	echo "kube-apiserver  is located in the same port"
else
	#check if user gives  a string and not an integer as port
	if ! [[ $kubeapi_port =~ $re ]] ; then 
		echo "kube api server error:given port is not number"
	else
		#check port availability
		availability="$(sudo netstat -lntup | grep ":$kubeapi_port")"
		if [ -n  "$availability" ] 
		then
      			
			use=1
			

      
		else
			use=0
			
		fi
		./change_kube_apiserverport.sh $kubeapi_port $use
		
	fi
fi
#same process for other services
if [ "$kubelet_port" = "null"  ] || [ "$kubelet_port" = "none"  ] || [ -z  "$kubelet_port" ]; then
	echo "kubelet  is located in the same port"
else
	
	if ! [[ $kubelet_port =~ $re ]] ; then 
		echo "kubelet error:given port is not number"
	else
		
		availability="$(sudo netstat -lntup | grep ":$kubelet_port")"
		if [ -n  "$availability" ] 
		then
      			
			use=1
      
		else
			use=0
			
		fi
		./change_kubeletport.sh $kubelet_port $use



		
	fi	





fi

if [ "$kube_scheduler" = "null"  ] || [ "$kube_scheduler" = "none"  ] || [ -z  "$kube_scheduler" ]; then
	echo "kube-scheduler  is located in the same port"
else
	
		
	if ! [[ $kube_scheduler =~ $re ]] ; then 
		echo "kube-scheduler error:given port is not number"
	else
		
		

			availability="$(sudo netstat -lntup | grep ":$kube_scheduler")"
		if [ -n  "$availability" ] 
		then
      			
      			use=1
		else
			use=0
		fi
		./change_kube_schedulerport.sh $kube_scheduler $use


	fi	


fi


if [ "$kube_controller" = "null"  ] || [ "$kube_controller" = "none"  ] || [ -z  "$kube_controller" ]; then 
	echo "kube-controller-manager  is located in the same port"
else
	
	if ! [[ $kube_controller =~ $re ]] ; then 
		echo "kube-controller-manager error:given port is not number"
	else
		availability="$(sudo netstat -lntup | grep ":$kube_controller")"
		
		if [ -n  "$availability" ] 
		then
      			
			use=1
      
		else
			use=0
			echo $kube_controller
		fi
		./change_kube_controllerport.sh $kube_controller $use



	fi





fi




if [ "$kube_proxy_metrics" = "null"  ] || [ "$kube_proxy_metrics" = "none"  ] || [ -z  "$kube_proxy_metrics" ]; then
	echo "metrics server  is located in the same port"
	use2=-1
	kube_proxy_metrics="none"
else
	

	if ! [[ $kube_proxy_metrics =~ $re ]] ; then 
		echo "metrics server error:given port is not number"
		use2=-1
	else
		
		
		availability="$(sudo netstat -lntup | grep ":$kube_proxy_metrics")"
		if [ -n  "$availability" ] 
		then
      			
			use2=1
      
		else
			use2=0
			#echo $kube_proxy_metrics
		fi






	fi



fi


if [ "$kube_proxy_healthz" = "null"  ] || [ "$kube_proxy_healthz" = "none"  ] || [ -z  "$kube_proxy_healthz" ]; then
	echo "server for health check  is located in the same port"
	use1=-1
	kube_proxy_healthz="none"
else
	

	if ! [[ $kube_proxy_healthz =~ $re ]] ; then 
		echo "server for health check error:given port is not number"
		use1=-1
	else
		
		availability="$(sudo netstat -lntup | grep ":$kube_proxy_healthz")"
		if [ -n  "$availability" ] 
		then
      			
			use1=1

      
		else
			use1=0
			#echo $kube_proxy_healthz
		fi
	fi



fi

./change_kube_proxyports.sh $kube_proxy_healthz $use1 $kube_proxy_metrics $use2

# tell kubelet about the new kubeconfig
sudo sed -i 's#${SNAP}/configs/kubelet.config#${SNAP_DATA}/kubelet.config#' /var/snap/microk8s/current/args/kubelet


# disable and enable the microk8s snap to restart all services
sudo snap disable microk8s && sudo snap enable microk8s

microk8s.inspect

#unsnap kubectl
snap aliases
sudo snap unalias kubectl
KUBECONFIG=~/.kube/microk8s.config kubectl get all
sudo systemctl restart snap.microk8s.daemon-apiserver
sudo systemctl restart snap.microk8s.daemon-kubelet
sudo systemctl restart snap.microk8s.daemon-scheduler
sudo systemctl restart snap.microk8s.daemon-controller-manager
sudo systemctl restart snap.microk8s.daemon-proxy
microk8s.inspect



