#!/bin/bash
#get_initial ports
input="/var/snap/microk8s/current/args/"
filename="kube-proxy"
path=$input$filename

while IFS= read -r line
do
	
  if [[ $line == *"healthz-port="* ]]; then
	
  	port_str1=$line
  else
	if [[ $line == *"--metrics-port"* ]]; then
		port_str2=$line
	fi
  fi
done < "$path"

#echo $port_str1
parts=$(echo $port_str1 | tr "=" "\n")
count=0
#echo "sep"
DEFAULT_PORT1=10256
for item in $parts
do
   if [ $count -eq  1 ]; 
   then
	DEFAULT_PORT1=$item
   fi
   let "count++"
done

echo "default port to bind the health check server:"$DEFAULT_PORT1

#echo $port_str2
parts=$(echo $port_str2 | tr "=" "\n")
count=0
#echo "sep"
DEFAULT_PORT2=10249
for item in $parts
do
   if [ $count -eq  1 ]; 
   then
	DEFAULT_PORT2=$item
   fi
   let "count++"
done

echo "default port for the metrics server to serve on:"$DEFAULT_PORT2


# define our new ports number
API_PORT1=$1
use1=$2
API_PORT2=$3
use2=$4
echo $API_PORT1
echo $API
#when ports omited
if [ -z  "$API_PORT1" ]
then
	use1=-1
fi

if [ -z  "$API_PORT2" ]  
then
	use2=-1
fi

#check if new port is same with old
#for proxy healthz
if [ $use1 -eq  1 ]; then 
	if [ $API_PORT1 = $DEFAULT_PORT1 ]; then
		echo "server-health check has already used "$API_PORT1
	else
		echo "Port $API_PORT1 for server-health check is not available"
	fi
	
else
	if [ $use1 -eq  0 ]; then 
		echo "server-health check port configuration"
		# update kube-proxy for check health args with the new port
		echo "--healthz-port=$API_PORT1" | sudo tee -a /var/snap/microk8s/current/args/kube-proxy
		# tell other services about the new port
		sudo find /var/snap/microk8s/current/args -type f -exec sed -i "s/DEFAULT_PORT1/$API_PORT1/g" {} ';'
		# create new, updated copies of our kubeconfig for kubelet and kubectl to use
		mkdir -p ~/.kube && microk8s.config -l  | sed "s/:DEFAULT_PORT1/:$API_PORT1/" | sudo tee /var/snap/microk8s/current/kubelet.config > ~/.kube/microk8s.config
	fi
fi

#for proxy metrics
if [ $use2 -eq  1 ]; then 
	if [ $API_PORT2 = $DEFAULT_PORT2 ]; then
		echo "metrics server has already used "$API_PORT2
	else
		echo "Port $API_PORT2 for metrics server is not available"
	fi
	
else
	if [ $use2 -eq  0 ]; then  
		echo "metrics server port configuration"
		# update kube-proxy for metrics args with the new port
		echo "--metrics-port=$API_PORT2" | sudo tee -a /var/snap/microk8s/current/args/kube-proxy
		# tell other services about the new port
		sudo find /var/snap/microk8s/current/args -type f -exec sed -i "s/DEFAULT_PORT2/$API_PORT2/g" {} ';'
		# create new, updated copies of our kubeconfig for kubelet and kubectl to use
		mkdir -p ~/.kube && microk8s.config -l  | sed "s/:DEFAULT_PORT2/:$API_PORT2/" | sudo tee /var/snap/microk8s/current/kubelet.config > ~/.kube/microk8s.config

	fi
fi

<<////
if [ $use1 -eq 0 ] || [ $use2 -eq 0 ]; then
	echo "other general configurations for changing proxy server ports"
	#general activities for two sevices

	# tell kubelet about the new kubeconfig
	sudo sed -i 's#${SNAP}/configs/kubelet.config#${SNAP_DATA}/kubelet.config#' /var/snap/microk8s/current/args/kubelet


	# disable and enable the microk8s snap to restart all services
	sudo snap disable microk8s && sudo snap enable microk8s

	microk8s.inspect

	#unsnap kubectl
	snap aliases
	sudo snap unalias kubectl
	KUBECONFIG=~/.kube/microk8s.config kubectl get all

	sudo systemctl restart snap.microk8s.daemon-proxy
	microk8s.inspect
fi
////
<< ////
# update kube-proxy for check health args with the new port
echo "--healthz-port=$API_PORT1" | sudo tee -a /var/snap/microk8s/current/args/kube-proxy
# tell other services about the new port
sudo find /var/snap/microk8s/current/args -type f -exec sed -i "s/DEFAULT_PORT1/$API_PORT1/g" {} ';'
# create new, updated copies of our kubeconfig for kubelet and kubectl to use

mkdir -p ~/.kube && microk8s.config -l  | sed "s/:DEFAULT_PORT1/:$API_PORT1/" | sudo tee /var/snap/microk8s/current/kubelet.config > ~/.kube/microk8s.config


# update kube-proxy for metrics args with the new port
echo "--metrics-port=$API_PORT2" | sudo tee -a /var/snap/microk8s/current/args/kube-proxy
# tell other services about the new port
sudo find /var/snap/microk8s/current/args -type f -exec sed -i "s/DEFAULT_PORT2/$API_PORT2/g" {} ';'
# create new, updated copies of our kubeconfig for kubelet and kubectl to use
mkdir -p ~/.kube && microk8s.config -l  | sed "s/:DEFAULT_PORT2/:$API_PORT2/" | sudo tee /var/snap/microk8s/current/kubelet.config > ~/.kube/microk8s.config



#general activities for two sevices

# tell kubelet about the new kubeconfig
sudo sed -i 's#${SNAP}/configs/kubelet.config#${SNAP_DATA}/kubelet.config#' /var/snap/microk8s/current/args/kubelet


# disable and enable the microk8s snap to restart all services
sudo snap disable microk8s && sudo snap enable microk8s

microk8s.inspect

#unsnap kubectl
snap aliases
sudo snap unalias kubectl
KUBECONFIG=~/.kube/microk8s.config kubectl get all

sudo systemctl restart snap.microk8s.daemon-proxy
microk8s.inspect
////
