#!/bin/bash

#get initial port
input="/var/snap/microk8s/current/args/"
filename="kube-scheduler"
path=$input$filename

while IFS= read -r line
do
	
  if [[ $line == *"--port="* ]]; then
	
  	port_str=$line
  fi
done < "$path"

#echo $port_str
parts=$(echo $port_str | tr "=" "\n")
count=0
#echo "sep"
DEFAULT_PORT=10251
for item in $parts
do
   if [ $count -eq  1 ]; 
   then
	DEFAULT_PORT=$item
   fi
   let "count++"
done

echo "default port:"$DEFAULT_PORT


# define our new port number

API_PORT=$1
use=$2

#check if new port is same with old
if [ $use -eq  1 ]; then 
	if [ $API_PORT = $DEFAULT_PORT ]; then
		echo "kube-scheduler has already used "$API_PORT
	else
		echo "Port $API_PORT for kube-scheduler is not available"
	fi
	exit
fi
echo "kube-scheduler port configuration"


# update kube-apiserver args with the new port
echo "--port=$API_PORT" | sudo tee -a /var/snap/microk8s/current/args/kube-scheduler
# tell other services about the new port
sudo find /var/snap/microk8s/current/args -type f -exec sed -i "s/DEFAULT_PORT/$API_PORT/g" {} ';'

# create new, updated copies of our kubeconfig for kubelet and kubectl to use

mkdir -p ~/.kube && microk8s.config -l  | sed "s/:DEFAULT_PORT/:$API_PORT/" | sudo tee /var/snap/microk8s/current/kubelet.config > ~/.kube/microk8s.config
<<////
# tell kubelet about the new kubeconfig
sudo sed -i 's#${SNAP}/configs/kubelet.config#${SNAP_DATA}/kubelet.config#' /var/snap/microk8s/current/args/kubelet


# disable and enable the microk8s snap to restart all services
sudo snap disable microk8s && sudo snap enable microk8s

microk8s.inspect

#unsnap kubectl
snap aliases
sudo snap unalias kubectl
KUBECONFIG=~/.kube/microk8s.config kubectl get all

sudo systemctl restart snap.microk8s.daemon-scheduler
microk8s.inspect
////
